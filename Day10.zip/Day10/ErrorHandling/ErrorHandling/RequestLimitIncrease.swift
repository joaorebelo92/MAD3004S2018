//
//  RequestLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class RequestLimitIncrease{
    var accountInfo = [
        "S1100" : requestFromAccount(type: "Saving", balance: 2312.43),
        "S1200" : requestFromAccount(type: "Saving", balance: 3000.43),
        "S1300" : requestFromAccount(type: "Chequing", balance: 8276.00),
        "S1400" : requestFromAccount(type: "Saving", balance: 6758.21),
    ]
    
    func increaseLimit(accountNo : String) throws{
        guard let recAcc = accountInfo[accountNo] else{
            throw limitIncreaseError.ineligible
        }
        
        guard recAcc.type == "Saving" else{
            throw limitIncreaseError.noSavingAccount
        }
        
        guard recAcc.balance >= 5000 else{
            throw limitIncreaseError.insufficientBalance(balanceNeeded: 5000 - recAcc.balance)
        }
        
        print("Congratulations!... Your request is approved.")
        
    }
}

struct requestFromAccount {
    var type: String
    var balance: Double
}

enum limitIncreaseError: Error {
    case ineligible
    case noSavingAccount
    case insufficientBalance(balanceNeeded: Double)
}
