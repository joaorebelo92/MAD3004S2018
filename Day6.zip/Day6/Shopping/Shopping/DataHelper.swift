//
//  DataHelper.swift
//  Shopping
//
//  Created by joao rebelo on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var ProductList = [Int : Product]()
    init() {
        self.loadProductData()
    }
    
    func loadProductData(){
        ProductList = [:]
        
        let epson = Product(productID: 101, productName: "Projector", manufacturer: "Epson", category: ProductCategory.Appliances, unitPrice: 1000.1)
        ProductList[epson.ProductID!] = epson
        
        let handcream = Product(productID: 101, productName: "Handcream", manufacturer: "Glysomed", category: ProductCategory.Health, unitPrice: 12.23)
        ProductList[handcream.ProductID!] = handcream
        
        let flask = Product(productID: 102, productName: "Flask", manufacturer: "Contigo", category: ProductCategory.Appliances, unitPrice: 20)
        ProductList[flask.ProductID!] = flask
        
        let zelda = Product(productID: 103, productName: "The Legend of Zelda", manufacturer: "Nintendo", category: ProductCategory.Books, unitPrice: 27.97)
        ProductList[zelda.ProductID!] = zelda
        
        let sapiens = Product(productID: 104, productName: "Sapiens", manufacturer: "Yuval Noah Harari", category: ProductCategory.Books, unitPrice: 11.89)
        ProductList[sapiens.ProductID!] = sapiens
        
        let socks = Product(productID: 105, productName: "Puma Men's 6 pack Low Cut Socks", manufacturer: "Puma", category: ProductCategory.Clothing, unitPrice: 23.40)
        ProductList[socks.ProductID!] = socks
        
        let dress = Product(productID: 106, productName: "Women's Vintage Floral Cocktail Dress", manufacturer: "OWIN", category: ProductCategory.Clothing, unitPrice: 45)
        ProductList[dress.ProductID!] = dress
    }
    
    func displayProducts(){
        for (_, value) in self.ProductList.sorted(by: {$0.key < $1.key}){
        //for (key, value) in self.ProductList {
            //print("key = \(key)")
            print(value.displayData())
        }
    }
}
