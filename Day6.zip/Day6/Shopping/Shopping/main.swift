//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

/*
var Santosh = Customer()

Santosh.customerID = "c101"
//Santosh.customerName = "Santosh"
print(Santosh.displayData())

var Param = Customer(customerID: "c102", customerName: "Paramjeet", address: "114 Michigan Ave. Brampton", email: "param@mad.com", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "ship to lambton college between 08:00 AM to 12:00 PM")
print(Param.displayData())

var Saloni = Customer()

Saloni.registerUser()
print(Saloni.displayData())

Saloni.CustomerName  = "Sallu"
Saloni.ShippingInfo = "Deliver between 10AM to 12 PM"

print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 Marjary Ave. DownTown. Toronto"
Santosh.CreditCardInfo = "4520-0100-6543-8976"
Santosh.ShippingInfo = "Delivery at Papa John's at 03PM"

print(Santosh.displayData())
*/
/*
var epson = Product(productID: 101, productName: "Projector", manufacturer: "Epson", category: ProductCategory.Appliances, unitPrice: 1000.1)
print(epson.displayData())

var handcream = Product()
handcream.newProduct()
print(handcream.displayData())
*/

var dataHelper = DataHelper()
dataHelper.displayProducts()




