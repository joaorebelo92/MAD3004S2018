//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)

var greet = """
Haallo Friends,
How are you doing!
Cludy weather...
Boring class
Funny Friends
"""

print(greet)

let mLine = """
test
"""

let mood2 = "\u{24}"
print(mood2)

let mood = "\u{1F496}"
print(mood)

if mood.isEmpty {
    print("No mood")
}else{
    greet += mood
}
print(greet)

var team = String()
team = "Croatia"
print(team)

for i in team{
    print(i)
}

var inicial : Character = "J"

team.append(inicial)

print(team)

team.append(" GO GO GO")
print(team)

print("Length of team : ", team.count)

print("Start Index of team : \(team[team.startIndex])")

//print("End Index of team : \(team[team.endIndex])")
print("Last character of team : \(team[team.index(before: team.endIndex)])")

print("some character : \(team[team.index(after: team.startIndex)])")

print("4th character : \(team[team.index(team.startIndex, offsetBy: 3)])")

print("4th character from end: \(team[team.index(team.endIndex, offsetBy: -5)])")

var idx = team.index(team.endIndex, offsetBy: -5)
print("\(idx)")

print("\(team[idx])")


for index in greet.indices{
    print("\(greet[index])", terminator: "_")
}

for (index, value) in team.enumerated(){
    print("index : \(index) --- Value : \(value)")
}

print(team)

team.insert("!", at: team.endIndex)

print(team)

team.insert(contentsOf: " Win it..", at: team.endIndex)
print(team)

var idx1 = team.index(of: "J") ?? team.endIndex
print("idx1 : \(idx1)")

team.remove(at: idx1)



var idxG = team.index(of: "G") ?? team.endIndex
team.removeSubrange(team.startIndex..<idxG)

var idxI = team.index(of: "t") ?? team.endIndex

var idxW = team.index(of: "w") ?? team.startIndex

var win = team[idxW..<idxI]
print("\(win)")

var idxLast = win.index(win.endIndex, offsetBy: -2)
win = win[win.startIndex...idxLast]


print("\(win)")

print(team.uppercased())
print(team)


var grade : String?
grade = "A"
let finalGrade = grade ?? "F"
print("\(finalGrade)")














