//
//  TempEmployee.swift
//  Day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TempEmployee: Employee, INetPayCalculation{
    var hoursHoliday : Int?
    
    var netPay : Double?{
        get{
            if self.hoursHoliday! > 10 {
                return self.basicPay! - 100
            }else{
                return self.basicPay!
            }
        }
    }
    
    required init(empID : Int, empName : String, basicPay : Double, holiday : Int) {
        self.hoursHoliday = holiday
        super.init(empID: empID, empName: empName, basicPay: basicPay)
    }
    
    override func display() {
        super.display()
        print("Hours of Holiday : \(self.hoursHoliday ?? 0)")
        print("Net Pay: \(self.netPay?.asCurrency ?? self.basicPay?.asCurrency ?? 0.0.asCurrency)")
    }
    
}
